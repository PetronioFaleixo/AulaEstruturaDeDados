import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
        public static void main(String[] args) {
            Deque<Pessoa> pessoas = new ArrayDeque<>();
            Scanner ler = new Scanner(System.in);
            int num;
            String nome;
            String email;
            String telefone;
            Pessoa pessoa;

            for (num = 0; num < 3; num++) {
                System.out.println("digite as infos da pessoa, nome, telefone,email");

                nome = ler.nextLine();
                telefone = ler.nextLine();
                email = ler.nextLine();


                pessoa = new Pessoa(nome, telefone, email);
                pessoas.add(pessoa);
            }
            for (Iterator itr = pessoas.iterator(); itr.hasNext();){
                System.out.println(itr.next().toString());
            }
            System.out.println();
            for (Iterator itr = pessoas.descendingIterator(); itr.hasNext();) {
                System.out.println(itr.next().toString());
            }
        }
}